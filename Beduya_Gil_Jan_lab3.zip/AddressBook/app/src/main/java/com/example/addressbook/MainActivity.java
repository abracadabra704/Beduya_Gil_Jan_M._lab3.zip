package com.example.addressbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button contact1;
    private Button contact2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contact1=(Button) findViewById(R.id.contact1);
        contact1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencontact1();
            }
        });
        contact2=(Button) findViewById(R.id.contact2);
        contact2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencontact2();
            }
        });
    }
    public void opencontact1(){
        Intent intent = new Intent(this, contact1.class);
        startActivity(intent);

    }
    public void opencontact2(){
        Intent intent = new Intent(this, contact2.class);
        startActivity(intent);

    }
}